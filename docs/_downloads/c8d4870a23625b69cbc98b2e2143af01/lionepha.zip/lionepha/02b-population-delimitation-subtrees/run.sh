#! /bin/bash
cd 00 && bash bpp00.job && cd -
cd 01 && bash bpp01.job && cd -
cd 02 && bash bpp02.job && cd -
cd 03 && bash bpp03.job && cd -
cd 04 && bash bpp04.job && cd -
cd 05 && bash bpp05.job && cd -
cd 06 && bash bpp06.job && cd -
cd 07 && bash bpp07.job && cd -
cd 08 && bash bpp08.job && cd -
cd 09 && bash bpp09.job && cd -
cd 10 && bash bpp10.job && cd -
