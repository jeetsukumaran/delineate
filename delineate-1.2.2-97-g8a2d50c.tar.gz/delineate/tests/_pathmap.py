#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
TESTS_DIR = os.path.abspath(os.path.dirname(__file__))
SRC_DIR = os.path.join(os.path.dirname(TESTS_DIR), "src")
TESTS_DATA_DIR = os.path.abspath(os.path.join(TESTS_DIR, "data"))
BIN_DIR = os.path.join(os.path.dirname(TESTS_DIR), "bin")


