#! /bin/bash
cd 00 && qsub bpp00.job && cd -
cd 01 && qsub bpp01.job && cd -
cd 02 && qsub bpp02.job && cd -
cd 03 && qsub bpp03.job && cd -
cd 04 && qsub bpp04.job && cd -
cd 05 && qsub bpp05.job && cd -
cd 06 && qsub bpp06.job && cd -
cd 07 && qsub bpp07.job && cd -
cd 08 && qsub bpp08.job && cd -
cd 09 && qsub bpp09.job && cd -
cd 10 && qsub bpp10.job && cd -
